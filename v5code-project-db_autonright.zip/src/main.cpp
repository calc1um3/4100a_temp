#include "vex.h"
#include "string.h" 
#include "vexshortcuts.h"
#include <iostream>
// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// ML                   motor         5               
// SIXBAR_EXT           motor         7               
// Controller1          controller                    
// SIXBAR               motor_group   6, 8            
// Drivetrain           drivetrain    1, 4, 3, 2      
// ---- END VEXCODE CONFIGURED DEVICES ----



using namespace vex;
competition Competition;





void pre_auton(void) {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();

  ML.setRotation(0 ,degrees);
  SIXBAR.setRotation(0 ,degrees); // same as above but 6bar



//DRIVETRAIN CONSTRUCTOR



//2.33


  
}//Drivetrain.turnFor(180, degrees, 100, velocityUnits::pct, true);

void autonomous(void) { //auton pd.


//ML.startSpinFor(-450, degrees, 100, velocityUnits::pct); //LOWER 6BAR EXTENSION


/*
Drivetrain.driveFor(-50, inches, 100, velocityUnits::pct, false); //DRIVE UP TO YELLOW

vex::task::sleep(2000);

SIXBAR_EXT.startSpinFor(900, degrees, 100, velocityUnits::pct); //LOWER 6BAR EXTENSION

vex::task::sleep(1000);

Drivetrain.turnFor(-180, degrees, 100, velocityUnits::pct, false); //TURN AROUND

vex::task::sleep(2000);

Drivetrain.driveFor(40, inches, 100, velocityUnits::pct, false); //MOVE BACK TO STARTING AREA

vex::task::sleep(2000);

SIXBAR_EXT.startSpinFor(-900, degrees, 100, velocityUnits::pct); //DROP YELLOW
*/


}










void usercontrol(void) {
  bool snapEnabled = false;

//ML bool vals
 
  bool L1Holding = false;
  bool R1Holding = false;


//SIXBAR bool vals
  bool R2Holding = false;
  bool L2Holding = false;

//SIXBAR_EXT bool vals

  

  
  while (1) {   

/////////////////////////////////////////////////////////////////
    //Controller Inputs -- ML

    if(Controller1.ButtonL1.pressing())
    {
      R1Holding = true;
    }
    if(!Controller1.ButtonL1.pressing())
    {
      R1Holding = false;
      ML.stop(brakeType::hold);
    }
    if(Controller1.ButtonL2.pressing())
    {
      L1Holding = true;
    }
    if(!Controller1.ButtonL2.pressing())
    {
      L1Holding = false;
      ML.stop(brakeType::hold);
    }
////////////////////////////////////////////////////////////

   //Controller Inputs -- SIXBAR

    if(Controller1.ButtonR1.pressing())
    {
      R2Holding = true;
    }
    else if(!Controller1.ButtonR1.pressing())
    {
      R2Holding = false;
      SIXBAR.stop();
     
    }
    if(Controller1.ButtonR2.pressing())
    {
      L2Holding = true;
    }
    else if(!Controller1.ButtonR2.pressing())
    {
      L2Holding = false;
      SIXBAR.stop();
     
    }


/////////////////////////////////////////////////////////
    //Controller Inputs - SIXBAR_EXT
    bool UpHolding = false;
    bool DownHolding = false;
   
    if(Controller1.ButtonUp.pressing())
    {
      UpHolding = true;
    }
    if(!Controller1.ButtonUp.pressing())
    {
      UpHolding = false;
      SIXBAR_EXT.stop(hold);
    }
    if(Controller1.ButtonDown.pressing())
    {
      DownHolding = true;
    }
    if(!Controller1.ButtonDown.pressing())
    {
      DownHolding = false;
      SIXBAR_EXT.stop(hold);
    }

/////////////////////////////////////////////////////////
    //SIXBAR ext 

    if(UpHolding == true && DownHolding == false)
    {
      SIXBAR_EXT.spin(forward, 90, velocityUnits::pct);
    }
    if(DownHolding == true && UpHolding == false)
    {
       SIXBAR_EXT.spin(reverse, 90, velocityUnits::pct);
    }
    
    


/////////////////////////////////////////////////////////
    //lift without snap - SIXBAR

    if(R2Holding == true && L2Holding == false && snapEnabled == false) 
    {
      SIXBAR.spin(forward, 90, velocityUnits::pct); //extend
    }
    if(L2Holding == true && R2Holding == false && snapEnabled == false) 
    {
      SIXBAR.spin(reverse, 90, velocityUnits::pct); //retract
    }


///////////////////////////////////////////////////////
    //lift without snap - ML

    if(R1Holding == true && L1Holding == false && snapEnabled == false) // && ML.rotation(degrees)
    {
      ML.spin(forward, 90, velocityUnits::pct);
    }
    if(L1Holding == true && R1Holding == false && snapEnabled == false) // && ML.rotation(degrees)
    {
      ML.spin(reverse, 90, velocityUnits::pct);
    }
    wait(20, msec); //so robot doesnt die
                    
  } 
}





int main() {
 
  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);

  
  // Run the pre-autonomous function.
  pre_auton();



  // stops robot from throwing a fit
  while (true) {
    wait(100, msec);
  }
}
