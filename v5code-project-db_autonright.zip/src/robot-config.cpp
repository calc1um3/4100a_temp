#include "vex.h"

using namespace vex;
using signature = vision::signature;
using code = vision::code;

// A global instance of brain used for printing to the V5 Brain screen
brain  Brain;

// VEXcode device constructors
motor ML = motor(PORT5, ratio36_1, true);
motor SIXBAR_EXT = motor(PORT7, ratio36_1, true);
controller Controller1 = controller(primary);
motor SIXBARMotorA = motor(PORT6, ratio36_1, false);
motor SIXBARMotorB = motor(PORT8, ratio36_1, true);
motor_group SIXBAR = motor_group(SIXBARMotorA, SIXBARMotorB);
motor leftMotorA = motor(PORT1, ratio36_1, false);
motor leftMotorB = motor(PORT4, ratio36_1, false);
motor_group LeftDriveSmart = motor_group(leftMotorA, leftMotorB);
motor rightMotorA = motor(PORT3, ratio36_1, true);
motor rightMotorB = motor(PORT2, ratio36_1, true);
motor_group RightDriveSmart = motor_group(rightMotorA, rightMotorB);
drivetrain Drivetrain = drivetrain(LeftDriveSmart, RightDriveSmart, 319.19, 406.4, 241.29999999999998, mm, 2.3333333333333335);

// VEXcode generated functions
// define variable for remote controller enable/disable
bool RemoteControlCodeEnabled = true;

/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Pro.
 * 
 * This should be called at the start of your int main function.
 */
void vexcodeInit( void ) {
  // nothing to initialize
}