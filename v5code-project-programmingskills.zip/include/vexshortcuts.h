#include "vex.h"
#include "string.h"


void ChangeAngle(motor motorName, double target, double speed ) //Moves motor to target position
{
  motorName.startSpinFor(target, degrees, speed, velocityUnits::pct); //speed in %

  //dir-> direction
  //target -> target angle (in degrees),
  // 95 -> 95 velocity units.
}


/*

void SpinWithLimits(motor motorName,brakeType brakingType,bool incPress, bool decPress, int encoderMaxAllow, int encoderMinAllow)
{
 //motorName -> name of motor targeted
 //incpress/decpress -> bool values that should be assigned on controller press, e.g. on ButtonA press, incpress == true, etc.
 //encoder min/max -> maximum/minimum encoder angle to move motor in a given direction (fwd, bkwd)



  if(incPress == true && motorName.position >= encoderMinAllow)
  {
    motorName.spin(forward, 90, velocityUnits::pct); //rotate where encoder increases
  }

  if(decPress == true)
  {
    motorName.spin(reverse, 90, velocityUnits::pct); //rotate where encoder decreases
  }

  if(!incPress && !decPress)
  {
    motorName.stop(brakingType);
  }

}

*/




void Delay(int time) {
    wait(time, msec);
}



void ChangeAngleSnap(motor motorName, bool boolval, double target, double speed )
{
  if(boolval)
  {
    motorName.startSpinFor(target, degrees, speed, velocityUnits::pct);
    boolval = 0;
    vex::task::sleep(250);
  }
  else if (!boolval)
  {
    motorName.startSpinFor(target, degrees, speed, velocityUnits::pct);
    boolval = 1;
    vex::task::sleep(250);
  }
}
