#include "string.h"
#include "vexshortcuts.h" 
#include "vex.h"

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// miniLift             motor         5               
// sixbar               motor         6               
// sixbar_ext           motor         7               
// Controller1          controller                    
// sixbar2              motor         8               
// Drivetrain           drivetrain    4, 1, 2, 3      
// ---- END VEXCODE CONFIGURED DEVICES ----



using namespace vex;


competition Competition;



void pre_auton(void) {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();
  
  miniLift.setRotation(0 ,degrees);
  sixbar.setRotation(0 ,degrees); // same as above but 6bar
  
}



void autonomous(void) { //auton pd.



/*
//IN DEVELOPMENT DO NOT USE IT DOES NOT WORK
miniLift.startSpinFor(-450, degrees, 100, velocityUnits::pct);

Drivetrain.driveFor(36, inches, 100, velocityUnits::pct, false);
vex::task::sleep(2500);

Drivetrain.turnFor(-90, degrees, 100, velocityUnits::pct, false);
vex::task::sleep(2500);

Drivetrain.driveFor(36, inches, 100, velocityUnits::pct, false);
vex::task::sleep(2500);

Drivetrain.driveFor(-36, inches, 100, velocityUnits::pct, false);
vex::task::sleep(2500);

Drivetrain.turnFor(90, degrees, 100, velocityUnits::pct, false);
vex::task::sleep(2500);

Drivetrain.driveFor(-36, inches, 100, velocityUnits::pct, false);


*/




 //V1 USE ON 1/29 COMP

Drivetrain.driveFor(96, inches, 100, velocityUnits::pct, false);
vex::task::sleep(4500);

Drivetrain.driveFor(-67, inches, 100, velocityUnits::pct, false);
vex::task::sleep(4000);

Drivetrain.turnFor(90, degrees, 100, velocityUnits::pct, false);
vex::task::sleep(2000);

Drivetrain.driveFor(82, inches, 100, velocityUnits::pct, false);
vex::task::sleep(4000);

Drivetrain.turnFor(-90, degrees, 100, velocityUnits::pct, false);
vex::task::sleep(2000);

Drivetrain.driveFor(96, inches, 100, velocityUnits::pct, false);
vex::task::sleep(4000);



} 
//left motors 1, 4, reverse
//right motors 2,3

void usercontrol(void) {

}




int main() {
 
  Competition.autonomous(autonomous);
  //Competition.drivercontrol(usercontrol);

  
  // Run the pre-autonomous function.
  pre_auton();



  // stops robot from throwing a fit
  while (true) {
    wait(100, msec);
  }
}
