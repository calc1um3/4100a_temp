#include "vex.h"
#include "string.h"
#include "vexshortcuts.h"
// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// FrontLeft            motor         1               
// FrontRight           motor         3               
// BackLeft             motor         4               
// BackRight            motor         2               
// miniLift             motor         5               
// sixbar               motor         6               
// sixbar_ext           motor         7               
// Controller1          controller                    
// sixbar2              motor         8               
// ---- END VEXCODE CONFIGURED DEVICES ----


using namespace vex;


competition Competition;



void pre_auton(void) {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();

  miniLift.setRotation(0 ,degrees);
  sixbar.setRotation(0 ,degrees); // same as above but 6bar
  
}

void autonomous(void) { //auton pd.

MoveInches(12,70);

Delay(1000);

sixbar_ext.startSpinFor(900, degrees, 100, velocityUnits::pct);

Delay(1000);

MoveInches(-12,70);

sixbar_ext.startSpinFor(-900, degrees, 100, velocityUnits::pct);

Delay(3000);

TurnDegrees(-90,1000);

Delay(1000);
MoveInches(24,100);
Delay(1000);

TurnDegrees(45,100);
MoveInches(50,100);

}










void usercontrol(void) {
  bool snapEnabled = false;

//minilift bool vals
 
  bool L1Holding = false;
  bool R1Holding = false;


//sixbar bool vals
  bool liftInDownPosSB = true;
  bool R2Holding = false;
  bool L2Holding = false;

//sixbar_ext bool vals

  

  
  while (1) {   

    //Drivetrain
    FrontLeft.spin(forward, Controller1.Axis3.position(percent), velocityUnits::pct); 
    BackLeft.spin(forward, Controller1.Axis3.position(percent), velocityUnits::pct);
    FrontRight.spin(forward, Controller1.Axis2.position(percent), velocityUnits::pct);
    BackRight.spin(forward, Controller1.Axis2.position(percent), velocityUnits::pct);
    
////////////////////////////////////////////////////////////////

    //SNAP TOGGLE
    if(Controller1.ButtonA.pressing())
    {
      if(snapEnabled == true)
      {
        Controller1.rumble(".");
      
        snapEnabled = false;
        vex::task::sleep(250);
      }
      else if(snapEnabled == false)
      {
        Controller1.rumble(".");
        snapEnabled = true;
      
        vex::task::sleep(250);
      }
      
      vex::task::sleep(500);


      
    }

    
  

/////////////////////////////////////////////////////////////////
    //Controller Inputs -- minilift

    if(Controller1.ButtonL1.pressing())
    {
      R1Holding = true;
    }
    if(!Controller1.ButtonL1.pressing())
    {
      R1Holding = false;
      miniLift.stop();
    }
    if(Controller1.ButtonL2.pressing())
    {
      L1Holding = true;
    }
    if(!Controller1.ButtonL2.pressing())
    {
      L1Holding = false;
      miniLift.stop();
    }
////////////////////////////////////////////////////////////

   //Controller Inputs -- sixbar

    if(Controller1.ButtonR1.pressing())
    {
      R2Holding = true;
    }
    else if(!Controller1.ButtonR1.pressing())
    {
      R2Holding = false;
      sixbar.stop();
      sixbar2.stop();
    }
    if(Controller1.ButtonR2.pressing())
    {
      L2Holding = true;
    }
    else if(!Controller1.ButtonR2.pressing())
    {
      L2Holding = false;
      sixbar.stop();
      sixbar2.stop();
    }


/////////////////////////////////////////////////////////
    //Controller Inputs - sixbar_ext
    bool UpHolding = false;
    bool DownHolding = false;
   
    if(Controller1.ButtonUp.pressing())
    {
      UpHolding = true;
    }
    if(!Controller1.ButtonUp.pressing())
    {
      UpHolding = false;
      sixbar_ext.stop(hold);
    }
    if(Controller1.ButtonDown.pressing())
    {
      DownHolding = true;
    }
    if(!Controller1.ButtonDown.pressing())
    {
      DownHolding = false;
      sixbar_ext.stop(hold);
    }

/////////////////////////////////////////////////////////
    //sixbar ext snap

    if(UpHolding == true && DownHolding == false)
    {
      sixbar_ext.spin(forward, 90, velocityUnits::pct);
    }
    if(DownHolding == true && UpHolding == false)
    {
       sixbar_ext.spin(reverse, 90, velocityUnits::pct);
    }
    
    


/////////////////////////////////////////////////////////
    //lift without snap - sixbar

    if(R2Holding == true && L2Holding == false && snapEnabled == false && sixbar.rotation(degrees) <= 800) 
    {
      sixbar.spin(forward, 90, velocityUnits::pct); //extend
      sixbar2.spin(forward, 90, velocityUnits::pct);
    }
    if(L2Holding == true && R2Holding == false && snapEnabled == false && sixbar.rotation(degrees) >= -800) 
    {
      sixbar.spin(reverse, 90, velocityUnits::pct); //retract
      sixbar2.spin(reverse, 90, velocityUnits::pct);
    }

    //lift with snap - sixbar

    if(Controller1.ButtonR2.pressing() && snapEnabled == true && liftInDownPosSB == true)
    {
      ChangeAngle(sixbar,100,800); //extend
      liftInDownPosSB = false;
      vex::task::sleep(250);
    }
    if(Controller1.ButtonL2.pressing() && snapEnabled == true && liftInDownPosSB == false)
    {
      ChangeAngle(sixbar,100,-800); //retract
      liftInDownPosSB = true;
      vex::task::sleep(250);
    }


///////////////////////////////////////////////////////
    //lift without snap - minilift

    if(R1Holding == true && L1Holding == false && snapEnabled == false) // && miniLift.rotation(degrees)
    {
      miniLift.spin(forward, 90, velocityUnits::pct);
    }
    if(L1Holding == true && R1Holding == false && snapEnabled == false) // && miniLift.rotation(degrees)
    {
      miniLift.spin(reverse, 90, velocityUnits::pct);
    }

    //lift with snap - minilift

    

    wait(20, msec); //so robot doesnt die
                    
  } 
}





int main() {
 
  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);

  
  // Run the pre-autonomous function.
  pre_auton();



  // stops robot from throwing a fit
  while (true) {
    wait(100, msec);
  }
}
